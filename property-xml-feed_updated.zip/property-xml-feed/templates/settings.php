<?php
global $wpdb;
// Get all unique property types from the post table
$property_types = $wpdb->get_col("
    SELECT DISTINCT post_type 
    FROM {$wpdb->posts} 
    WHERE post_type != 'revision' 
    AND post_type != 'nav_menu_item'
    AND post_type != 'custom_css'
    AND post_type != 'customize_changeset'
    AND post_type != 'oembed_cache'
");

$selected_property_type = get_option('property_xml_feed_post_type');

// Get the current configuration
$current_config = include(plugin_dir_path(__FILE__) . '../settings.php');

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize input
    $new_config = array(
        'logo' => sanitize_text_field($_POST['logo'] ?? $current_config['logo']),
        'cron_time' => absint($_POST['cron_time'] ?? $current_config['cron_time']),
        'log_deletion_days' => absint($_POST['log_deletion_days'] ?? $current_config['log_deletion_days']),
        'contact_form7' => array(
            'name_keys' => isset($_POST['cf7_name_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['cf7_name_keys'])) : $current_config['contact_form7']['name_keys'],
            'email_keys' => isset($_POST['cf7_email_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['cf7_email_keys'])) : $current_config['contact_form7']['email_keys'],
            'phone_keys' => isset($_POST['cf7_phone_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['cf7_phone_keys'])) : $current_config['contact_form7']['phone_keys'],
            'subject_keys' => isset($_POST['cf7_subject_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['cf7_subject_keys'])) : $current_config['contact_form7']['subject_keys'],
            'message_keys' => isset($_POST['cf7_message_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['cf7_message_keys'])) : $current_config['contact_form7']['message_keys'],
        ),
        'wpforms' => array(
            'name_keys' => isset($_POST['wpforms_name_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['wpforms_name_keys'])) : $current_config['wpforms']['name_keys'],
            'email_keys' => isset($_POST['wpforms_email_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['wpforms_email_keys'])) : $current_config['wpforms']['email_keys'],
            'phone_keys' => isset($_POST['wpforms_phone_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['wpforms_phone_keys'])) : $current_config['wpforms']['phone_keys'],
            'subject_keys' => isset($_POST['wpforms_subject_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['wpforms_subject_keys'])) : $current_config['wpforms']['subject_keys'],
            'message_keys' => isset($_POST['wpforms_message_keys']) ? array_map('sanitize_text_field', explode(',', $_POST['wpforms_message_keys'])) : $current_config['wpforms']['message_keys'],
        ),
        'export_xml_feed_pagination_limit' => absint($_POST['export_xml_feed_pagination_limit'] ?? $current_config['export_xml_feed_pagination_limit']),
    );
    //! give permission to change settings in file 0777
    chmod(plugin_dir_path(__FILE__) . '../settings.php', 0777);

    // Update the config file
    $config_file = plugin_dir_path(__FILE__) . '../settings.php';
    file_put_contents($config_file, '<?php return ' . var_export($new_config, true) . ';');

    // Update WordPress options
    update_option('property_xml_feed_config', $new_config);
    update_option('property_xml_feed_post_type', $_POST['property_type']);
    inject_reference_id_on_activation();

    echo '<div class="updated"><p>Settings saved successfully!</p></div>';
}

// Get the current settings
$config = get_option('property_xml_feed_config', $current_config);
?>

<form method="post" action="#">
    <table class="form-table">
        <img src="<?php echo esc_attr($config['logo']); ?>" alt="Logo">
        <h1>Settings</h1>
        <tr>
            <th scope="row"><label for="logo">Logo URL</label></th>
            <td><input type="text" id="logo" name="logo" value="<?php echo esc_attr($config['logo']); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="cron_time">Cron Time (seconds)</label></th>
            <td><input type="number" id="cron_time" name="cron_time" value="<?php echo esc_attr($config['cron_time']); ?>" class="small-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="log_deletion_days">Log Deletion Days</label></th>
            <td><input type="number" id="log_deletion_days" name="log_deletion_days" value="<?php echo esc_attr($config['log_deletion_days']); ?>" class="small-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="property_type">Property Types</label></th>
            <td>
                <select id="property_type" name="property_type" class="regular-text">
                    <?php foreach ($property_types as $property_type): ?>
                        <option value="<?php echo esc_attr($property_type); ?>" <?php selected($selected_property_type, $property_type); ?>><?php echo esc_html($property_type); ?></option>
                    <?php endforeach; ?>
                </select>
            </td>
        </tr>
        <tr>
            <th scope="row"><label for="export_xml_feed_pagination_limit">Export XML Feed Pagination Limit</label></th>
            <td><input type="number" id="export_xml_feed_pagination_limit" name="export_xml_feed_pagination_limit" value="<?php echo esc_attr($config['export_xml_feed_pagination_limit']); ?>" class="small-text"></td>
        </tr>
    </table>

    <h3>Contact Form 7 Settings</h3>
    <table class="form-table">
        <tr>
            <th scope="row"><label for="cf7_name_keys">Name Keys</label></th>
            <td><input type="text" id="cf7_name_keys" name="cf7_name_keys" value="<?php echo esc_attr(implode(',', $config['contact_form7']['name_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="cf7_email_keys">Email Keys</label></th>
            <td><input type="text" id="cf7_email_keys" name="cf7_email_keys" value="<?php echo esc_attr(implode(',', $config['contact_form7']['email_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="cf7_phone_keys">Phone Keys</label></th>
            <td><input type="text" id="cf7_phone_keys" name="cf7_phone_keys" value="<?php echo esc_attr(implode(',', $config['contact_form7']['phone_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="cf7_subject_keys">Subject Keys</label></th>
            <td><input type="text" id="cf7_subject_keys" name="cf7_subject_keys" value="<?php echo esc_attr(implode(',', $config['contact_form7']['subject_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="cf7_message_keys">Message Keys</label></th>
            <td><input type="text" id="cf7_message_keys" name="cf7_message_keys" value="<?php echo esc_attr(implode(',', $config['contact_form7']['message_keys'])); ?>" class="regular-text"></td>
        </tr>
    </table>

    <h3>WPForms Settings</h3>
    <table class="form-table">
        <tr>
            <th scope="row"><label for="wpforms_name_keys">Name Keys</label></th>
            <td><input type="text" id="wpforms_name_keys" name="wpforms_name_keys" value="<?php echo esc_attr(implode(',', $config['wpforms']['name_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="wpforms_email_keys">Email Keys</label></th>
            <td><input type="text" id="wpforms_email_keys" name="wpforms_email_keys" value="<?php echo esc_attr(implode(',', $config['wpforms']['email_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="wpforms_phone_keys">Phone Keys</label></th>
            <td><input type="text" id="wpforms_phone_keys" name="wpforms_phone_keys" value="<?php echo esc_attr(implode(',', $config['wpforms']['phone_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="wpforms_subject_keys">Subject Keys</label></th>
            <td><input type="text" id="wpforms_subject_keys" name="wpforms_subject_keys" value="<?php echo esc_attr(implode(',', $config['wpforms']['subject_keys'])); ?>" class="regular-text"></td>
        </tr>
        <tr>
            <th scope="row"><label for="wpforms_message_keys">Message Keys</label></th>
            <td><input type="text" id="wpforms_message_keys" name="wpforms_message_keys" value="<?php echo esc_attr(implode(',', $config['wpforms']['message_keys'])); ?>" class="regular-text"></td>
        </tr>
    </table>

    <?php submit_button('Save Settings'); ?>
</form>

<button id="logout-button" class="button button-primary">Logout From Laravel</button>