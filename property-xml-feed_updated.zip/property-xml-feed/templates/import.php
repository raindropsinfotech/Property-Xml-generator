<?php
if (!defined('ABSPATH')) {
    exit;
}

require_once plugin_dir_path(__FILE__) . '../config.php';
global $config;

//! login shortcode code
do_shortcode('[laravel_login_form]');

// Get current date to use in the log filename
$current_date = date('Y-m-d');
// Define the path for the log file, using the date
$pluginData = get_plugin_data( __DIR__ );
$pluginName = $pluginData['TextDomain'];
$log_file = WP_PLUGIN_DIR . '/'.$pluginName.'/logs/inmoconnect_log_import_' . $current_date . '.txt';

// Check if file exists, if not create one
if (!file_exists($log_file)) {
    // Create a new file and add header content (optional)
    $log_data = "Log File Created on: " . date('Y-m-d H:i:s') . "\n";
    $log_data .= "=====================================\n";
    file_put_contents($log_file, $log_data, FILE_APPEND | LOCK_EX);
}

$requirements = my_custom_plugin_check_requirements();
if(empty($requirements['all_requirements_met']) || $requirements['all_requirements_met'] == ""){
    echo '<div class="notice notice-error is-dismissible"><p>Requirements not met.</p></div>';
    echo '<a href="/wp-admin?page=my_custom_plugin_setup_wizard">Go to Setup Wizard</a>';
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_xml_feed'])) {
    check_admin_referer('property_xml_feed_import_action', 'property_xml_feed_import_nonce');
    $xml_feed_url = esc_url_raw($_POST['xml_feed_url']);
    //! store the xml feed url in database
    update_option('xml_feed_url', $xml_feed_url);
    if (filter_var($xml_feed_url, FILTER_VALIDATE_URL)) {
        $xml = get_xml_feed_with_token($xml_feed_url);
        if ($xml !== false) {
            if(get_option('property_xml_feed_post_type') == ""){
                choose_property_type();
            }else{
                display_mapping_form($xml);
            }
        } else {
            echo '<div class="notice notice-error"><p>Failed to load XML feed. Please check the URL.</p></div>';
        }
    } else {
        echo '<div class="notice notice-error"><p>Invalid URL. Please enter a valid XML feed URL.</p></div>';
    }
}

if (isset($_POST['import_mapped_data'])) {
    check_admin_referer('property_xml_feed_mapping_action', 'property_xml_feed_mapping_nonce');
    $mappings = $_POST['mapping'];
    $xml_feed_url = esc_url_raw($_POST['xml_feed_url']);
    $xml_data = get_xml_feed_with_token($xml_feed_url);
    
    if (isset($xml_data->pagination)) {
        $currentPage = intval($xml_data->pagination->page);
        $totalPages = intval($xml_data->pagination->total_pages);
    } else {
        $currentPage = 1;
        $totalPages = 1;
    }

    set_transient('property_import_progress', array(
        'current_page' => $currentPage,
        'total_pages' => $totalPages
    ), HOUR_IN_SECONDS);

    import_properties_from_xml($xml_data, $mappings);

    if ($currentPage < $totalPages) {
        // echo '<div class="notice notice-success"><p>Properties imported successfully! And Cron is set for the next Pages.</p></div>';
        echo '<div class="notice notice-success"><p>Properties imported successfully! Current page number is '. $currentPage .'.</p></div>';
        $next_page = $currentPage + 1;
        // wp_schedule_single_event(time() + 300, 'import_properties_from_xml_feed', array($mappings, $xml_feed_url, $next_page));
        ?>
        <script>
            updateProgressBar();
        </script>
        <?php
        importNextPage($mappings, $xml_feed_url, $next_page);
    } else {
        echo '<div class="notice notice-success"><p>All Properties imported successfully!</p></div>';
    }
}

if(isset($_POST['selected_property_type'])){
    //! get the xml feed url from database
    $xml_feed_url = get_option('xml_feed_url');
    $selected_property_type = sanitize_text_field($_POST['selected_property_type']);
    //! set the selected property type in the database
    update_option('property_xml_feed_post_type', $selected_property_type);
    if (filter_var($xml_feed_url, FILTER_VALIDATE_URL)) {
        $xml = get_xml_feed_with_token($xml_feed_url);
        if ($xml !== false) {
            inject_reference_id_on_activation();
            display_mapping_form($xml);
        } else {
            echo '<div class="notice notice-error"><p>Failed to load XML feed. Please check the URL.</p></div>';
        }
    } else {
        echo '<div class="notice notice-error"><p>Invalid URL. Please enter a valid XML feed URL.</p></div>';
    }
}

function choose_property_type(){
    global $wpdb;
    
    // Get all unique property types from the post table
    $property_types = $wpdb->get_col("
        SELECT DISTINCT post_type 
        FROM {$wpdb->posts} 
        WHERE post_type != 'revision' 
        AND post_type != 'nav_menu_item'
        AND post_type != 'custom_css'
        AND post_type != 'customize_changeset'
        AND post_type != 'oembed_cache'
    ");

    echo '<div class="wrap">';
    echo '<h1>Choose Property Type</h1>';
    echo '<form method="post" id="choose_property_type_form">';
    echo '<select name="selected_property_type">';
    echo '<option value="">All Property Types</option>';
    
    foreach ($property_types as $type) {
        echo '<option value="' . esc_attr($type) . '">' . esc_html($type) . '</option>';
    }
    
    echo '</select>';
    echo '<input type="submit" name="choose_property_type" value="Continue" class="button button-primary">';
    echo '</form>';
    echo '</div>';
}

function importNextPage($mappings, $xml_feed_url, $page) {
    $xml_feed_url_with_page = add_query_arg('page', $page, $xml_feed_url);
    $xml_data = get_xml_feed_with_token($xml_feed_url_with_page);
    
    if (isset($xml_data->pagination)) {
        $currentPage = intval($xml_data->pagination->page);
        $totalPages = intval($xml_data->pagination->total_pages);
    } else {
        $currentPage = 1;
        $totalPages = 1;
    }

    if ($xml_data->properties->property === false) {
        return;
    }

    set_transient('property_import_progress', array(
        'current_page' => $currentPage,
        'total_pages' => $totalPages
    ), HOUR_IN_SECONDS);

    import_properties_from_xml($xml_data, $mappings);

    if ($currentPage < $totalPages) {
        echo '<div class="notice notice-success"><p>Properties imported successfully! Current page number is '. $currentPage .'.</p></div>';
        $next_page = $currentPage + 1;
        // wp_schedule_single_event(time() + 300, 'import_properties_from_xml_feed', array($mappings, $xml_feed_url, $next_page));
        ?>
        <script>
            updateProgressBar();
        </script>
        <?php
        importNextPage($mappings, $xml_feed_url, $next_page);
    } else {
        wp_schedule_single_event(time() + 300, 'import_properties_from_xml_feed_cronwhole', array($mappings, $xml_feed_url, 1));
        echo '<div class="notice notice-success"><p>All Properties imported successfully!</p></div>';
    }
}

function display_mapping_form($xml) {
    global $wpdb;

    $meta_keys = $wpdb->get_col("SELECT DISTINCT meta_key FROM {$wpdb->postmeta} WHERE post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = '".get_option('property_xml_feed_post_type', 'property')."')");
    //! Add 'post_title' and 'post_content' to the list of available fields
    $default_fields = array('post_title', 'post_content');

    //! Merge default fields (title, content) with custom meta keys
    $db_fields = array_merge($default_fields, $meta_keys);
    // $db_fields = $meta_keys;
    $xml_fields = [];

    // Traverse the XML structure to gather all fields
    foreach ($xml->properties->property as $property) {
        foreach ($property as $section) {
            foreach ($section as $field => $value) {
                $xml_fields[] = (string)$field;
            }
        }
    }

    $xml_fields = array_unique($xml_fields);
    ?>
    <div class="wrap">
        <h1>Map XML Fields to Database Fields</h1>
        <form method="post" id="xml-import-form">
            <input type="hidden" name="xml_feed_url" value="<?php echo get_option('xml_feed_url'); ?>" />
            <?php wp_nonce_field('property_xml_feed_mapping_action', 'property_xml_feed_mapping_nonce'); ?>
            <h2>Mapping Fields</h2>
            <table class="form-table">
                <tr>
                    <th scope="row">Database Fields</th>
                    <th scope="row">XML Fields</th>
                </tr>
                <?php
                foreach ($db_fields as $db_field) {
                    echo '<tr>';
                    echo '<td>' . esc_html($db_field) . '</td>';
                    echo '<td>';
                    echo '<select name="mapping[' . esc_attr($db_field) . ']">';
                    echo '<option value="">Select XML Field</option>';
                    foreach ($xml_fields as $xml_key => $xml_value) {
                        if(strpos($db_field, 'title')){
                            echo '<option '. (($xml_value == 'name') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'content')){
                            echo '<option '. (($xml_value == 'description') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'price')){
                            echo '<option '. (($xml_value == 'price') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'bedrooms')){
                            echo '<option '. (($xml_value == 'bedrooms') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'rooms')){
                            echo '<option '. (($xml_value == 'rooms') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'bathrooms')){
                            echo '<option '. (strpos($xml_value, 'bathrooms') || ($xml_value == 'bathrooms') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'location') || strpos($db_field, 'address')){
                            echo '<option '. (($xml_value == 'address') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'year')){
                            echo '<option '. (($xml_value == 'year') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'zip')){
                            echo '<option '. (($xml_value == 'postcode') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'reference')){
                            echo '<option '. (($xml_value == 'reference') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }elseif(strpos($db_field, 'property_id')){
                            echo '<option '. (($xml_value == 'id') ? 'selected' : '') .' value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }else{
                            echo '<option value="' . esc_attr($xml_value) . '">' . esc_html($xml_value) . '</option>';
                        }
                    }
                    echo '</select>';
                    echo '</td>';
                    echo '</tr>';
                }
                ?>
            </table>
            <?php submit_button('Import Mapped Data', 'primary', 'import_mapped_data'); ?>
        </form>
    </div>
    <?php
}
?>
<?php
if (empty($_POST)) {
?>
    <div class="wrap">
        <h1>Import Property XML Feed</h1>
        <form method="post">
            <?php wp_nonce_field('property_xml_feed_import_action', 'property_xml_feed_import_nonce'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><label for="xml_feed_url">XML Feed URL</label></th>
                    <td>
                        <input type="url" name="xml_feed_url" id="xml_feed_url" value="" placeholder="https://www.staging.inmoconnect.com/xml-feed" required />
                    </td>
                </tr>
            </table>
            <?php submit_button('Import XML Feed', 'primary', 'import_xml_feed'); ?>
        </form>
    </div>
<?php
}
?>
