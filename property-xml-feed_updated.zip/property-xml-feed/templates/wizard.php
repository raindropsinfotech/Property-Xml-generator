    <div id="myCustomPluginWizardModal" class="my-custom-plugin-modal">
        <div class="my-custom-plugin-modal-content">
            <span class="my-custom-plugin-close">&times;</span>
            <h2>Plugin Setup Wizard</h2>
            <div class="wizard-step" id="wizard-step-1">
                <h2>Step 1: Import Properties</h2>
                <!-- <p>On this page : <a href="/wp-admin/admin.php?page=property-xml-feed-import">Import Page</a></p>
                <p>You need to add a url of the feed of the properties given by the Inmoconnect. </p>
                <p>For example : <a href="https://www.inmoconnect.com/property-feed" target="_blank">https://www.inmoconnect.com/property-feed</a></p> -->
                <p>Configure the basic settings for your plugin.</p>
                <!-- Add form fields for configuration -->
                <input type="text" name="basic_config" placeholder="Enter basic configuration" />
                <button class="next-btn" data-next="2">Next</button>
            </div>
            <div class="wizard-step" id="wizard-step-2" style="display:none;">
                <h3>Step 2: Advanced Configuration</h3>
                <p>Configure advanced settings for your plugin.</p>
                <!-- Add form fields for advanced configuration -->
                <input type="text" name="advanced_config" placeholder="Enter advanced configuration" />
                <button class="next-btn" data-next="3">Next</button>
            </div>
            <div class="wizard-step" id="wizard-step-3" style="display:none;">
                <h3>Step 3: Final Step</h3>
                <p>Complete the setup process for your plugin.</p>
                <!-- Final step actions -->
                <button class="finish-btn">Finish</button>
            </div>
        </div>
    </div>

    <script>
    jQuery(document).ready(function($) {
        // Show the next step when "Next" is clicked
        $('#next-button').on('click', function() {
            $('#wizard-step-1').hide();
            $('#wizard-step-2').show();
        });

        // Finalize setup when "Finish" is clicked
        $('#finish-button').on('click', function() {
            alert('Setup complete!');
            window.location.href = '<?php echo admin_url(); ?>'; // Redirect to the admin dashboard
        });
    });
    </script>