<?php

if ( ! class_exists( 'WP_Async_Request' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'wp-async-request.php'; // Include the library
}
if ( ! class_exists( 'WP_Background_Process' ) ) {
    require_once plugin_dir_path( __FILE__ ) . 'wp-background-process.php'; // Include the library
}

// Extend the WP_Background_Process class
class Property_Import_Process extends WP_Background_Process {

    protected $action = 'property_import_process';

    // Task to process each item in the queue
    protected function task( $args ) {
        $mappings = $args['mappings'];
        $xml_feed_url = $args['xml_feed_url'];
        $page = $args['page'];

        // Import the properties from XML for the current page
        $this->import_properties_from_xml_feed_handler($mappings, $xml_feed_url, $page);

        // Return false when the task is complete to stop processing
        return false;
    }

    // When the queue is completed
    protected function complete() {
        parent::complete();
        error_log('Property import process completed.');
    }

    // XML Import Handler
    public function import_properties_from_xml_feed_handler($mappings, $xml_feed_url, $page) {
        $xml_feed_url_with_page = add_query_arg('page', $page, $xml_feed_url);
        $xml_data = get_xml_feed_with_token($xml_feed_url_with_page);

        if ($xml_data) {
            // Get pagination info
            if (isset($xml_data->pagination)) {
                $currentPage = intval($xml_data->pagination->page);
                $totalPages = intval($xml_data->pagination->total_pages);
            } else {
                $currentPage = 1;
                $totalPages = 1;
            }

            // Update progress in the options table for tracking
            update_option('property_import_progress', [
                'current_page' => $currentPage,
                'total_pages' => $totalPages,
            ]);

            // Import properties
            $this->import_properties_from_xml($xml_data, $mappings);

            // Schedule the next page if we haven't reached the last page
            if ($currentPage < $totalPages) {
                $next_page = $currentPage + 1;
                $this->push_to_queue([
                    'mappings' => $mappings,
                    'xml_feed_url' => $xml_feed_url,
                    'page' => $next_page,
                ]);
            }
        }
    }

    // Function to import properties from XML data
    public function import_properties_from_xml($xml_data, $mappings) {
        foreach ($xml_data->properties->property as $property) {
            $property_reference = (string) $property->property_information->reference;
            if (empty($property_reference)) {
                continue; // Skip properties without a reference
            }

            // Check if the property already exists
            $existing_post_id = check_if_property_exists($property_reference);

            if (!$existing_post_id) {
                // Create a new post for the property
                $new_post_id = wp_insert_post([
                    'post_title'   => (string)$property->property_information->name,
                    'post_content' => (string)$property->property_information->description,
                    'post_status'  => 'publish',
                    'post_type'    => 'property',
                ]);

                if ($new_post_id) {
                    // Loop through the mappings and save meta data
                    foreach ($mappings as $db_field => $xml_field) {
                        $value = get_field_from_xml($xml_field, $property);
                        if (!empty($value)) {
                            update_post_meta($new_post_id, $db_field, $value);
                        }
                    }
                }
            } else {
                // Update existing property
                foreach ($mappings as $db_field => $xml_field) {
                    $value = get_field_from_xml($xml_field, $property);
                    if (!empty($value)) {
                        update_post_meta($existing_post_id, $db_field, $value);
                    }
                }
            }
        }
    }
}
