jQuery(document).ready(function($) {
    // Show the modal on page load
    var modal = $('#myCustomPluginWizardModal');
    modal.show();

    // Close the modal when the close button is clicked
    $('.my-custom-plugin-close').click(function() {
        modal.hide();
    });

    // Handle next button clicks
    $('.next-btn').click(function() {
        var nextStep = $(this).data('next');
        $('.wizard-step').hide();  // Hide all steps
        $('#wizard-step-' + nextStep).show();  // Show the next step
    });

    // Handle the finish button click
    $('.finish-btn').click(function() {
        modal.hide();
        alert('Setup complete!');
    });

    // Close modal if user clicks outside of modal content
    $(window).click(function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });

    $('#logout-button').click(function() {
        console.log('Logout button clicked');
        $.ajax({
            url: ajax_url,
            type: 'POST',
            data: {
                action: 'logout_from_laravel'
            },
            success: function(response) {
                console.log('Logout successful');
                window.location.href = 'admin.php?page=property-xml-feed';
            },
            error: function(error) {
                console.log('Logout error:', error);
            }
        });
    });

    $('#generate_xml').click(function(event) {
        event.preventDefault();
        var mapping_form = $('#mapping_form');
        
        let isValid = true;

        // Check each required field
        mapping_form.find('[required]').each(function () {
            // console.log(this, 'hasnain');
          if (!$(this).val()) {
            isValid = false;
            $(this).addClass('error-message');
            $(this).addClass('error'); // Add error class if needed
          } else {
            $(this).removeClass('error-message');
            $(this).removeClass('error');
          }
        });

        // If form is not valid, prevent submission and show error message
        if (!isValid) {
            event.preventDefault();
            $('#error-message').show();
        } else {
            $('#error-message').hide();
            var generate_xml_form = $('#generate_xml_form');
            generate_xml_form.submit();
        }
    });
});