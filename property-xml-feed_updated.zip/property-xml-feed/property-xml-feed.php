<?php
/*
Plugin Name: Inmoconnect XML Feed
Description: A plugin to generate an XML feed of property details with Export and Import functionalities.
Version: 1.2.2
Author: Raindrops Infotech
*/

require_once plugin_dir_path(__FILE__) . 'Property_Import_Process.php';
require_once plugin_dir_path(__FILE__) . 'config.php';
global $config;

//! logout from laravel on deactive and delete plugin
register_deactivation_hook(__FILE__, 'deactivate_laravel_login');
function deactivate_laravel_login() {
    global $wpdb;
    $user_id = get_current_user_id();
    delete_user_meta($user_id, 'laravel_token');
    delete_user_meta($user_id, 'laravel_token_expiry');
    delete_user_meta($user_id, 'laravel_user_email');
    delete_user_meta($user_id, 'laravel_user_pass');
    $token_file = __DIR__ . '/token.php';
    unlink($token_file);
}



// Function to display the login form if no token is stored
function show_laravel_login_form() {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $config = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    $user_id = get_current_user_id();

    //! get user email and password from db
    $email = get_user_meta($user_id, 'laravel_user_email', true);
    $password = get_user_meta($user_id, 'laravel_user_pass', true);
    $token = get_user_meta($user_id, 'laravel_token', true);
    $token_expiry = get_user_meta($user_id, 'laravel_token_expiry', true);

    if ($email && $password && !$token || time() > $token_expiry) {
        $laravel_api_url = 'https://www.dashboard.inmoconnect.com/api/login'; // Update this URL
        $response = wp_remote_post($laravel_api_url, array(
            'body' => array(
                'email' => $email,
                'password' => $password
            )
        ));

        if (is_wp_error($response)) {
            wp_send_json_error(array('message' => 'Error connecting to Laravel API.'));
        } else {
            $body = json_decode(wp_remote_retrieve_body($response));

            if (isset($body->token)) {
                // Store the token in the WordPress database with an expiry of 1 day
                $user_id = get_current_user_id();
                update_user_meta($user_id, 'laravel_token', $body->token);
                update_user_meta($user_id, 'laravel_token_expiry', time() + DAY_IN_SECONDS);
                $token_data = [
                    'laravel_token' => $body->token,
                    'laravel_token_expiry' => time() + DAY_IN_SECONDS,
                ];

                // Path to the token.php file
                $token_file = __DIR__ . '/token.php';
                //! give permission to write the file
                chmod($token_file, 0777);
                //! empty the token file
                file_put_contents($token_file, '');

                // Write the token to the PHP file
                file_put_contents($token_file, '<?php return ' . var_export($token_data, true) . ';');
                // Redirect to another page
                wp_safe_redirect(admin_url('admin.php?page=property-xml-feed-import'));
                $token = get_user_meta($user_id, 'laravel_token', true);
                $token_expiry = get_user_meta($user_id, 'laravel_token_expiry', true);
                // wp_send_json_success();
            } else {
                // wp_send_json_error(array('message' => 'Invalid credentials.'));
            }
        }
    }

    // Check if token exists and is still valid
    if (!$token || time() > $token_expiry) {
        // No valid token, show the login form
        ?>
        <form id="laravel-login-form">
            <h2>Login to <img src="<?= $config['logo'] ?>"></h2>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Login">
        </form>
        <div id="laravel-login-message"></div>

        <script type="text/javascript">
            jQuery(document).ready(function($) {
                $('#laravel-login-form').submit(function(e) {
                    e.preventDefault();

                    var email = $('#email').val();
                    var password = $('#password').val();

                    $.ajax({
                        url: '<?php echo admin_url('admin-ajax.php'); ?>',
                        type: 'POST',
                        data: {
                            action: 'laravel_login',
                            email: email,
                            password: password
                        },
                        success: function(response) {
                            if (response.success) {
                                $('#laravel-login-message').html('<p>Login successful.</p>');
                                location.reload();
                            } else {
                                $('#laravel-login-message').html('<p>' + response.data.message + '</p>');
                            }
                        }
                    });
                });
            });
        </script>
        <?php
        die();
    } else {
        echo '<p>You are already logged in to Laravel.</p>';
    }
}
add_shortcode('laravel_login_form', 'show_laravel_login_form');

// Handle the login request
function handle_laravel_login() {
    $email = isset($_POST['email']) ? sanitize_email($_POST['email']) : '';
    $password = isset($_POST['password']) ? sanitize_text_field($_POST['password']) : '';

    // Laravel API URL
    $laravel_api_url = 'https://www.dashboard.inmoconnect.com/api/login'; // Update this URL

    // Send login request to Laravel API
    $response = wp_remote_post($laravel_api_url, array(
        'body' => array(
            'email' => $email,
            'password' => $password
        )
    ));

    if (is_wp_error($response)) {
        wp_send_json_error(array('message' => 'Error connecting to Laravel API.'));
    } else {
        $body = json_decode(wp_remote_retrieve_body($response));

        if (isset($body->token)) {
            // Store the token in the WordPress database with an expiry of 1 day
            $user_id = get_current_user_id();
            update_user_meta($user_id, 'laravel_user_email', $email);
            update_user_meta($user_id, 'laravel_user_pass', $password);
            update_user_meta($user_id, 'laravel_token', $body->token);
            update_user_meta($user_id, 'laravel_token_expiry', time() + DAY_IN_SECONDS);
            $token_data = [
                'laravel_token' => $body->token,
                'laravel_token_expiry' => time() + DAY_IN_SECONDS,
            ];

            // Path to the token.php file
            $token_file = __DIR__ . '/token.php';
            //! give permission to write the file
            chmod($token_file, 0777);
            file_put_contents($token_file, '');

            // Write the token to the PHP file
            file_put_contents($token_file, '<?php return ' . var_export($token_data, true) . ';');
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'Invalid credentials.'));
        }
    }
}
add_action('wp_ajax_laravel_login', 'handle_laravel_login');
add_action('wp_ajax_nopriv_laravel_login', 'handle_laravel_login');


if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// Admin Menus
function property_xml_feed_admin_menu() {
    add_menu_page(
        'Property XML Feed',
        'Property XML Feed',
        'manage_options',
        'property-xml-feed',
        'property_xml_feed_export_page',
        'dashicons-upload',
        6
    );

    $requirements = my_custom_plugin_check_requirements();

    // if ($requirements['all_requirements_met']) {

        add_submenu_page(
            'property-xml-feed',
            'Export',
            'Export',
            'manage_options',
            'property-xml-feed-export',
            'property_xml_feed_export_page'
        );

        add_submenu_page(
            'property-xml-feed',
            'Import',
            'Import',
            'manage_options',
            'property-xml-feed-import',
            'property_xml_feed_import_page'
        );
    // }

    add_submenu_page(
        'property-xml-feed',
        'Settings',
        'Settings',
        'manage_options',
        'property-xml-feed-settings',
        'property_xml_feed_settings_page'
    );
}
add_action('admin_menu', 'property_xml_feed_admin_menu');

// Hook for plugin activation
register_activation_hook(__FILE__, 'my_custom_plugin_activate');

function my_custom_plugin_activate() {
    // Redirect to the setup wizard after activation
    add_option('my_custom_plugin_do_activation_redirect', true);
}

// Redirect to the wizard page on activation
add_action('admin_init', 'my_custom_plugin_redirect_to_wizard');

function my_custom_plugin_redirect_to_wizard() {
    // Only do the redirect if the activation flag is set
    if (get_option('my_custom_plugin_do_activation_redirect', false)) {
        delete_option('my_custom_plugin_do_activation_redirect');
        wp_safe_redirect(admin_url('admin.php?page=my_custom_plugin_setup_wizard'));
        exit;
    }
}

// Create the setup wizard page (without adding it to the menu)
add_action('admin_menu', 'my_custom_plugin_create_setup_wizard');

function my_custom_plugin_create_setup_wizard() {
    // Create a hidden admin page for the setup wizard
    add_submenu_page(
        null, // This ensures the page is not added to the menu
        'Plugin Setup Wizard', // Page title
        'Setup Wizard', // Menu title (won't be shown since it's hidden)
        'manage_options', // Capability
        'my_custom_plugin_setup_wizard', // Menu slug
        'my_custom_plugin_render_wizard_page' // Callback function to render the page
    );
}

// Callback function to render the setup wizard page
function my_custom_plugin_render_wizard_page() {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $configData = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    // Check system requirements
    $requirements = my_custom_plugin_check_requirements();
    ?>
    <div class="wrap">
        <h1> <img src="<?= $configData['logo'] ?>"> Plugin Setup Wizard - Check Requirements</h1>
        <div class="requirements-check">
            <table class="form-table">
                <tr>
                    <th>PHP Version (>= 7.1)</th>
                    <td>
                        <?php echo $requirements['php_version']['status']; ?>
                        <span>Current: <?php echo phpversion(); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>MySQL Version (>= 5.4)</th>
                    <td>
                        <?php echo $requirements['mysql_version']['status']; ?>
                        <span>Current: <?php echo $requirements['mysql_version']['value']; ?></span>
                    </td>
                </tr>
                <tr>
                    <th>Max Execution Time (>= 600)</th>
                    <td>
                        <?php echo $requirements['max_execution_time']['status']; ?>
                        <span>Current: <?php echo ini_get('max_execution_time'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>Memory Limit (>= 128M)</th>
                    <td>
                        <?php echo $requirements['memory_limit']['status']; ?>
                        <span>Current: <?php echo ini_get('memory_limit'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>Post Max Size (>= 48M)</th>
                    <td>
                        <?php echo $requirements['post_max_size']['status']; ?>
                        <span>Current: <?php echo ini_get('post_max_size'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>Upload Max Filesize (>= 48M)</th>
                    <td>
                        <?php echo $requirements['upload_max_filesize']['status']; ?>
                        <span>Current: <?php echo ini_get('upload_max_filesize'); ?></span>
                    </td>
                </tr>
                <tr>
                    <th>WordPress Version (>= 4.6)</th>
                    <td>
                        <?php echo $requirements['wp_version']['status']; ?>
                        <span>Current: <?php echo $requirements['wp_version']['value']; ?></span>
                    </td>
                </tr>
            </table>

            <div class="wizard-buttons">
                <?php if ($requirements['all_requirements_met']) : ?>
                    <a href="admin.php?page=property-xml-feed-export" class="button button-primary">
                        Continue
                    </a>
                <?php else : ?>
                    <button type="button" class="button button-disabled" disabled>Fix Requirements</button>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <?php
}

// Function to check the system requirements
function my_custom_plugin_check_requirements() {
    global $wp_version;

    $requirements = [
        'php_version' => [
            'value' => phpversion(),
            'status' => version_compare(phpversion(), '7.1', '>=') ? '✔️' : '❌'
        ],
        'mysql_version' => [
            'value' => my_custom_plugin_get_mysql_version(),
            'status' => version_compare(my_custom_plugin_get_mysql_version(), '5.4', '>=') ? '✔️' : '❌'
        ],
        'max_execution_time' => [
            'value' => ini_get('max_execution_time'),
            'status' => ini_get('max_execution_time') >= 600 ? '✔️' : '❌'
        ],
        'memory_limit' => [
            'value' => ini_get('memory_limit'),
            'status' => (int) ini_get('memory_limit') >= 128 ? '✔️' : '❌'
        ],
        'post_max_size' => [
            'value' => ini_get('post_max_size'),
            'status' => (int) ini_get('post_max_size') >= 48 ? '✔️' : '❌'
        ],
        'upload_max_filesize' => [
            'value' => ini_get('upload_max_filesize'),
            'status' => (int) ini_get('upload_max_filesize') >= 48 ? '✔️' : '❌'
        ],
        'wp_version' => [
            'value' => $wp_version,
            'status' => version_compare($wp_version, '4.6', '>=') ? '✔️' : '❌'
        ]
    ];

    // Determine if all requirements are met
    $requirements['all_requirements_met'] = true;
    foreach ($requirements as $req) {
        if ($req['status'] === '❌') {
            $requirements['all_requirements_met'] = false;
            break;
        }
    }

    return $requirements;
}

// Helper function to get MySQL version
function my_custom_plugin_get_mysql_version() {
    global $wpdb;
    return $wpdb->db_version();
}

//! Hook into plugin activation
// register_activation_hook(__FILE__, 'inject_reference_id_on_activation');

function inject_reference_id_on_activation() {
    global $wpdb;
    
    // Query all 'property_type' posts
    $args = array(
        'post_type'      => get_option('property_xml_feed_post_type', 'property'),
        'posts_per_page' => -1, // Get all posts
        'post_status'    => 'publish'
    );

    $property_posts = get_posts($args);
    $counter = 1; // Initialize counter for reference ID suffix

    // Loop through each post
    foreach ($property_posts as $post) {
        $post_id = $post->ID;

        // Check for existing meta keys with "reference" in them
        $query = $wpdb->prepare(
            "SELECT meta_key FROM {$wpdb->postmeta} 
            WHERE post_id = %d AND meta_key LIKE %s",
            $post_id,
            '%reference%'
        );
        $existing_reference_keys = $wpdb->get_col($query);

        if (!empty($existing_reference_keys)) {
            // Use the first found reference key
            $reference_key = $existing_reference_keys[0];
            $reference_value = get_post_meta($post_id, $reference_key, true);
            
            if (empty($reference_value)) {
                // If the value is empty, generate a new reference ID
                $timestamp = time();
                $reference_id = 'IMPL' . $timestamp . $counter;
                update_post_meta($post_id, $reference_key, $reference_id);
                $counter++;
            }
        } else {
            // No existing reference key found, create a new one
            $new_reference_key = 'property_reference_id';
            $timestamp = time();
            $reference_id = 'IMPL' . $timestamp . $counter;
            add_post_meta($post_id, $new_reference_key, $reference_id);
            $counter++;
        }
    }
}


// Placeholder functions for Export and Import pages
function property_xml_feed_export_page() {
    include plugin_dir_path(__FILE__) . 'templates/export.php';
}

function property_xml_feed_import_page() {
    include plugin_dir_path(__FILE__) . 'templates/import.php';
}

function property_xml_feed_settings_page() {
    include plugin_dir_path(__FILE__) . 'templates/settings.php';
}

// Enqueue Admin Scripts and Styles
function property_xml_feed_admin_assets($hook) {
    /*if (strpos($hook, 'property-xml-feed') === false) {
        return;
    }*/
    wp_enqueue_style('property-xml-feed-admin-css', plugin_dir_url(__FILE__) . 'css/admin.css');
    wp_enqueue_script('property-xml-feed-admin-js', plugin_dir_url(__FILE__) . 'js/admin.js', array('jquery'), '1.0', true);
    wp_localize_script('property-xml-feed-admin-js', 'ajax_url', admin_url('admin-ajax.php'));
}
add_action('admin_enqueue_scripts', 'property_xml_feed_admin_assets');

// Handle XML Feed Generation
function handle_generate_property_xml_feed() {
    $config = CONFIG;
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $configData = $settings_data;
    } else {
        echo 'Settings file not found.';
    }

    // Check user capabilities
    if (!current_user_can('manage_options')) {
        wp_die('Unauthorized user');
    }

    // Verify nonce
    check_admin_referer('generate_property_xml_feed_action', 'generate_property_xml_feed_nonce');

    // Get mappings (assuming these are set up correctly in your plugin)
    $mappings = get_option('property_xml_feed_mappings', array());

    // Get current date to use in the log filename
    $current_date = date('Y-m-d');
    // Define the path for the log file, using the date
    $pluginData = get_plugin_data(__FILE__);
    $pluginName = $pluginData['TextDomain'];
    $xml_dir = WP_PLUGIN_DIR . '/' . $pluginName . '/xml/';
    $log_file = WP_PLUGIN_DIR . '/' . $pluginName . '/logs/inmoconnect_log_export_' . $current_date . '.txt';
    
    // Start logging data
    $log_data = "XML Feed generation started on: " . date('Y-m-d H:i:s') . "\n";

    if (!empty($mappings)) {
        $log_data .= "Exporting the following fields:\n";
        foreach ($mappings as $key => $field) {
            $log_data .= $key . ' => ' . $field . "\n";
        }
    } else {
        $log_data .= "No fields mapped for export.\n";
    }

    // Add a completion timestamp
    $log_data .= "XML Feed generation completed on: " . date('Y-m-d H:i:s') . "\n";
    $log_data .= "-------------------------------------\n";

    // Append the log data to the log file
    file_put_contents($log_file, $log_data, FILE_APPEND | LOCK_EX);

    $xml_structure = $config['feed_data'];

    // Ensure the xml directory exists
    if (!file_exists($xml_dir)) {
        wp_mkdir_p($xml_dir);
    }

    // Clear the xml folder by deleting existing files
    $files = glob($xml_dir . '*.xml'); // Get all XML files in the directory
    foreach ($files as $file) {
        if (is_file($file)) {
            unlink($file); // Delete the file
        }
    }

    // Pagination settings
    $properties_per_page = $configData['export_xml_feed_pagination_limit']; // Define the number of properties per page
    $total_properties = wp_count_posts('property')->publish; // Get total published properties
    $total_pages = ceil($total_properties / $properties_per_page); // Calculate the total number of pages

    for ($current_page = 1; $current_page <= $total_pages; $current_page++) {
        // Query properties for the current page
        $properties = new WP_Query(array(
            'post_type' => get_option('property_xml_feed_post_type', 'property'),
            'posts_per_page' => $properties_per_page,
            'paged' => $current_page // Fetch current page data
        ));

        if ($properties->have_posts()) {
            // Generate XML filename for the current page
            $filename = 'property-feed-page-' . $current_page . '.xml';
            $file_path = $xml_dir . $filename; // Store XML in the 'xml' folder

            // Start creating XML content
            $xml_content = '<?xml version="1.0" encoding="UTF-8"?>';
            $xml_content .= '<feed>';

            // Add pagination data
            $xml_content .= '<pagination>';
            $xml_content .= '<page>' . $current_page . '</page>';
            $xml_content .= '<per_page>' . $properties_per_page . '</per_page>';
            $xml_content .= '<total_pages>' . $total_pages . '</total_pages>';
            $xml_content .= '<total_items>' . $total_properties . '</total_items>';
            $xml_content .= '</pagination>';

            // Add property data
            $xml_content .= '<properties>';
            while ($properties->have_posts()) {
                $properties->the_post();
                $xml_content .= '<property>';

                foreach ($xml_structure as $section => $fields) {
                    $xml_content .= "<$section>";
                    foreach ($fields as $field) {
                        $meta_key = isset($mappings["{$section}_{$field}"]) ? $mappings["{$section}_{$field}"] : '';
                        $value = get_post_meta(get_the_ID(), $meta_key, true);

                        if (!is_array($value)) {
                            $xml_content .= "<$field>" . esc_html($value) . "</$field>";
                        } else {
                            $xml_content .= "<$field>" . esc_html('') . "</$field>";
                        }
                    }
                    $xml_content .= "</$section>";
                }

                $xml_content .= '</property>';
            }
            $xml_content .= '</properties>';
            $xml_content .= '</feed>';

            // Write the XML content to the file
            file_put_contents($file_path, $xml_content);

            wp_reset_postdata();
        }
    }

    // Provide a list of links to download the generated XML files
    echo '<h2>XML Feeds Generated</h2>';
    for ($page = 1; $page <= $total_pages; $page++) {
        $file_url = plugins_url('xml/property-feed-page-' . $page . '.xml', __FILE__);
        
        // Display the URL and copy button
        echo '<div class="export-division" style="display: flex;justify-content: flex-start;">';
        echo '<input type="text" class="export-url" id="url-' . $page . '" value="' . esc_url($file_url) . '" readonly style="width: 50%;padding: 10px;font-size: 16px;color: black;border: none;border-radius: 5px;cursor: pointer;transition: background-color 0.3s ease;" />';
        echo '<button class="export-url-button" onclick="copyToClipboard(\'url-' . $page . '\')" style="background-color: #0073aa;color: #fff;border: none;border-radius: 5px;cursor: pointer;transition: background-color 0.3s ease;">Copy URL</button>';
        echo '</div><br>';
        break;
    }

    // Add JavaScript for copying to clipboard
    echo '
    <script>
        function copyToClipboard(id) {
            var copyText = document.getElementById(id);
            copyText.select();
            document.execCommand("copy");
            alert("Copied the URL: " + copyText.value);
        }
    </script>
    ';


    exit;
}
add_action('admin_post_generate_property_xml_feed', 'handle_generate_property_xml_feed');



function check_if_property_exists($property_reference) {
    global $wpdb;

    //! First, check if a meta key containing "reference" exists
    $reference_meta_key = $wpdb->get_var("
        SELECT meta_key 
        FROM $wpdb->postmeta 
        WHERE meta_key LIKE '%reference%' 
        LIMIT 1
    ");

    if ($reference_meta_key) {
        // If a reference meta key exists, use it for the comparison
        $query = $wpdb->get_var($wpdb->prepare("
            SELECT post_id 
            FROM $wpdb->postmeta 
            WHERE meta_key = %s 
            AND meta_value = %s 
            LIMIT 1
        ", $reference_meta_key, $property_reference));
    } else {
        // If no reference meta key exists, fall back to 'property_reference_id'
        $query = $wpdb->get_var($wpdb->prepare("
            SELECT post_id 
            FROM $wpdb->postmeta 
            WHERE meta_key = 'property_reference_id' 
            AND meta_value = %s 
            LIMIT 1
        ", $property_reference));
    }

    return $query ? (int)$query : false;
}


//! cron
function schedule_xml_feed_import() {
    if (!wp_next_scheduled('import_properties_from_xml_feed')) {
        wp_schedule_event(time(), 'hourly', 'import_properties_from_xml_feed');
    }
}
add_action('init', 'schedule_xml_feed_import');

add_action('import_properties_from_xml_feed_cronwhole', 'import_properties_from_xml_feed_cronwhole_handler', 10, 3);
function import_properties_from_xml_feed_cronwhole_handler($mappings, $xml_feed_url, $page) {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $configData = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    error_log("Custom cron job started for whole.");
    $xml_feed_url_with_page = add_query_arg('page', $page, $xml_feed_url);
    $xml_data = get_xml_feed_with_token($xml_feed_url_with_page);

    if ($xml_data) {
        // error_log("XML data received." . print_r($xml_data, true));

        if (isset($xml_data->pagination)) {
            $currentPage = intval($xml_data->pagination->page);
            $totalPages = intval($xml_data->pagination->total_pages);
        } else {
            $currentPage = 1;
            $totalPages = 1;
        }
        error_log("Current page." . $currentPage);


        import_properties_from_xml($xml_data, $mappings);

        if ($currentPage < $totalPages) {
            $next_page = $currentPage + 1;
            // wp_schedule_single_event(time() + 300, 'import_properties_from_xml_feed', array($mappings, $xml_feed_url, $next_page));
            importNextPageCron($mappings, $xml_feed_url, $next_page);
        }else{
            wp_schedule_single_event(time() + $configData['cron_time'], 'import_properties_from_xml_feed_cronwhole', array($mappings, $xml_feed_url, 1));
            error_log("All properties imported whole.");
        }
    }
    error_log("Custom cron job finished whole.");
}

function importNextPageCron($mappings, $xml_feed_url, $page) {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $configData = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    $xml_feed_url_with_page = add_query_arg('page', $page, $xml_feed_url);
    $xml_data = get_xml_feed_with_token($xml_feed_url_with_page);
    
    if (isset($xml_data->pagination)) {
        $currentPage = intval($xml_data->pagination->page);
        $totalPages = intval($xml_data->pagination->total_pages);
    } else {
        $currentPage = 1;
        $totalPages = 1;
    }

    if ($xml_data->properties->property === false) {
        return;
    }

    import_properties_from_xml($xml_data, $mappings);

    if ($currentPage < $totalPages) {
        $next_page = $currentPage + 1;
        importNextPageCron($mappings, $xml_feed_url, $next_page);
    } else {
        wp_schedule_single_event(time() + $configData['cron_time'], 'import_properties_from_xml_feed_cronwhole', array($mappings, $xml_feed_url, 1));
        error_log("All properties imported whole.");
    }
}

add_action('import_properties_from_xml_feed', 'import_properties_from_xml_feed_handler', 10, 3);

function import_properties_from_xml_feed_handler($mappings, $xml_feed_url, $page) {
    error_log("Custom cron job started.");
    $xml_feed_url_with_page = add_query_arg('page', $page, $xml_feed_url);
    $xml_data = get_xml_feed_with_token($xml_feed_url_with_page);

    if ($xml_data) {
        // error_log("XML data received." . print_r($xml_data, true));

        if (isset($xml_data->pagination)) {
            $currentPage = intval($xml_data->pagination->page);
            $totalPages = intval($xml_data->pagination->total_pages);
        } else {
            $currentPage = 1;
            $totalPages = 1;
        }
        error_log("Current page." . $currentPage);


        import_properties_from_xml($xml_data, $mappings);

        if ($currentPage < $totalPages) {
            $next_page = $currentPage + 1;
            wp_schedule_single_event(time() + 300, 'import_properties_from_xml_feed', array($mappings, $xml_feed_url, $next_page));
        }
    }
    error_log("Custom cron job finished.");
}

/**
 * Function to upload an image from a URL and attach it to a post.
 *
 * @param string $image_url The image URL.
 * @param int $post_id The ID of the post to attach the image to.
 * @return int|WP_Error The attachment ID on success, or WP_Error on failure.
 */
function upload_and_attach_image($image_url, $post_id) {
    // Get the file name and download the file to WordPress uploads directory
    $file = download_url($image_url);

    if (is_wp_error($file)) {
        return $file; // Return error if download fails
    }

    $file_info = pathinfo($image_url);
    $file_name = sanitize_file_name($file_info['basename']);

    // Prepare file data for WordPress media upload
    $file_data = array(
        'name'     => $file_name,
        'type'     => mime_content_type($file), // Get MIME type
        'tmp_name' => $file,
        'error'    => 0,
        'size'     => filesize($file),
    );

    // Upload the image into the media library
    $attachment_id = media_handle_sideload($file_data, $post_id);

    // If there was an error during upload, delete the temporary file
    if (is_wp_error($attachment_id)) {
        @unlink($file); // Cleanup temp file
        return $attachment_id; // Return error
    }

    return $attachment_id; // Return the attachment ID on success
}

// Function to import properties
function import_properties_from_xml($xml_data, $mappings) {

    // Get current date to use in the log filename
    $current_date = date('Y-m-d');
    // Define the path for the log file, using the date
    $pluginData = get_plugin_data( __FILE__ );
    $pluginName = $pluginData['TextDomain'];
    $log_file = WP_PLUGIN_DIR . '/'.$pluginName.'/logs/inmoconnect_log_import_' . $current_date . '.txt';
    // Start logging data
    $log_data = "Import started on: " . date('Y-m-d H:i:s') . "\n";

    if ($xml_data->properties->property === false) {
        $log_data .= "Properties not found:\n";
        return;
    }

    foreach ($xml_data->properties->property as $property) {
        $property_reference = (string)$property->property_information->reference;
        if (empty($property_reference)) {
            continue; // Skip properties without a reference
        }

        // Check if the property already exists
        $existing_post_id = check_if_property_exists($property_reference);

        if (!$existing_post_id) {

            // Property doesn't exist, so create a new one
            $new_post_id = wp_insert_post(array(
                'post_title'   => (string)$property->property_information->name,
                'post_content' => (string)$property->property_information->description,
                'post_status'  => 'publish',
                'post_type'    => get_option('property_xml_feed_post_type', 'property'),
            ));

            if ($new_post_id && !is_wp_error($new_post_id)) {
                
                // Loop through the mappings and save meta data
                foreach ($mappings as $db_field => $xml_field) {
                    $value = get_field_from_xml($xml_field, $property);
                    if (!empty($value)) {
                        update_post_meta($new_post_id, $db_field, $value);
                    }
                }

                foreach ($mappings as $db_field => $xml_field) {
                    
                    $value = get_field_from_xml($xml_field, $property);
                    if (!empty($value)) {

                        if (is_array($value)) {
                            
                            $image_url = (string)$value[0];
                            $image_id = upload_and_attach_image($image_url, $new_post_id);
                            if ($image_id) {
                                set_post_thumbnail($new_post_id, $image_id);
                            }
                            // foreach ($value as $image) {
                            //     echo "Image: " . $image . "<br>";
                            // }
                        } else {
                            // Handle single value fields
                            update_post_meta($new_post_id, $db_field, $value);
                        }
                    }
                }
            }
            $log_data .= "Imported New Property ". $new_post_id .":\n";

        } else {
            // Property exists, so update it
            foreach ($mappings as $db_field => $xml_field) {
                $value = get_field_from_xml($xml_field, $property);
                if (!empty($value)) {
                    update_post_meta($existing_post_id, $db_field, $value);
                }
            }
            $log_data .= "Update Existing Property ". $existing_post_id .":\n";
        }
    }

    //! Add a completion timestamp
    $log_data .= "Import completed on: " . date('Y-m-d H:i:s') . "\n";
    $log_data .= "-------------------------------------\n";

    // Append the log data to the log file
    file_put_contents($log_file, $log_data, FILE_APPEND | LOCK_EX);
}

function save_property_meta($post_id, $property) {
    // Retrieve the mapping (should be defined in your admin or via options)
    $mappings = get_option('property_xml_feed_mappings', array());

    foreach ($mappings as $db_field => $xml_field) {
        $value = get_field_from_xml($xml_field, $property);
        if (!empty($value)) {
            update_post_meta($post_id, $db_field, $value);
        }
    }
}

function get_field_from_xml($field_name, $xml) {
    // Check if the field exists directly at this level
    if (isset($xml->$field_name)) {
        $field = $xml->$field_name;
        // Check if the field contains multiple values (is an array)
        if ($field instanceof SimpleXMLElement && isset($field->image)) {
            $images = [];
            foreach ($field->image as $image) {
                $images[] = (string)$image; // Convert each image element to a string
            }
            return $images; // Return array of images
        }
        return (string)$field; // Return the field value as a string
    }

    // Otherwise, recursively search through child elements
    foreach ($xml as $key => $value) {
        if ($value instanceof SimpleXMLElement) {
            // Recursive call to search within nested XML structures
            $result = get_field_from_xml($field_name, $value);
            if ($result !== null) {
                return $result;  // Return the value if found in child elements
            }
        }
    }

    // If the field was not found, return null
    return null;
}


function get_xml_feed_with_token($xml_feed_url) {
    $token_file = __DIR__ . '/token.php';
    if (file_exists($token_file)) {
        $token_data = include($token_file);

        // Check if the token has expired
        if (time() > $token_data['laravel_token_expiry']) {
            echo 'Token has expired.';
        } else {
            $token = $token_data['laravel_token'];
            // echo 'Token: ' . $token;
        }
    } else {
        echo 'Token file not found.';
    }

    /*// Get the current user ID
    $user_id = get_current_user_id();

    // Retrieve the stored token from user meta
    $token = get_user_meta($user_id, 'laravel_token', true);*/

    // Check if token is available
    if (!$token) {
        return 'No token found. Please log in first.';
    }

    // Initialize cURL
    $ch = curl_init();

    // Set cURL options
    curl_setopt($ch, CURLOPT_URL, $xml_feed_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    
    // Set the Authorization header with the token
    $headers = [
        "Authorization: Bearer $token",
    ];
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

    // Execute the cURL request
    $response = curl_exec($ch);

    // Check for cURL errors
    if (curl_errno($ch)) {
        $error_message = curl_error($ch);
        curl_close($ch);
        return "Error fetching XML feed: $error_message";
    }

    // Close the cURL session
    curl_close($ch);

    // Convert the response to a SimpleXMLElement
    $xml = simplexml_load_string($response);

    // Check if the XML is valid
    if ($xml === false) {
        return 'Failed to load XML.';
    }

    return $xml; // Return the XML object
}

add_action('wpcf7_mail_sent', 'send_contact_form_data_to_external_site');

function send_contact_form_data_to_external_site($contact_form) {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $config = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    // Get the token
    $token_file = __DIR__ . '/token.php';
    if (file_exists($token_file)) {
        $token_data = include($token_file);

        // Check if the token has expired
        if (time() > $token_data['laravel_token_expiry']) {
            echo 'Token has expired.';
        } else {
            $token = $token_data['laravel_token'];
            // echo 'Token: ' . $token;
        }
    } else {
        echo 'Token file not found.';
    }

    // Get the form data
    $submission = WPCF7_Submission::get_instance();
    
    if ($submission) {
        $posted_data = $submission->get_posted_data();

        $name_keys = $config['contact_form7']['name_keys'];
        $email_keys = $config['contact_form7']['email_keys'];
        $subject_keys = $config['contact_form7']['subject_keys'];
        $message_keys = $config['contact_form7']['message_keys'];
        $phone_keys = $config['contact_form7']['phone_keys'];
        
        // Helper function to find the first valid value from an array of keys
        function get_value_from_keys($keys, $posted_data) {
            foreach ($keys as $key) {
                if (!empty($posted_data[$key])) {
                    return $posted_data[$key];
                }
            }
            return ''; // Return an empty string if no value is found
        }

        // Get the form values by checking all possible keys
        $name = sanitize_text_field(get_value_from_keys($name_keys, $posted_data));
        $email = sanitize_email(get_value_from_keys($email_keys, $posted_data));
        $subject = sanitize_text_field(get_value_from_keys($subject_keys, $posted_data));
        $message = sanitize_textarea_field(get_value_from_keys($message_keys, $posted_data));
        $phone = sanitize_textarea_field(get_value_from_keys($phone_keys, $posted_data));

        // Prepare the data to send
        $data = array(
            'name' => $name,
            'email' => $email,
            'subject' => $subject,
            'phone' => $phone,
            'message' => $message,
        );

        // External site URL
        $url = 'https://www.dashboard.inmoconnect.com/api/store-agent-lead-details';

        // Send data to the external site using wp_remote_post
        $response = wp_remote_post($url, array(
            'method'    => 'POST',
            'body'      => $data,
            'headers'   => array(
                'Authorization' => 'Bearer ' . $token,
                'Content-Type' => 'application/x-www-form-urlencoded'
            ),
        ));

        // Optionally, log or handle the response
        if (is_wp_error($response)) {
            echo '<pre>';print_r($response);echo '</pre>';die();
        } else {
            // Log success or further actions
        }
    }
}

// Helper function to check if the field name matches any of the keys
function matches($fieldName, $keys) {
    foreach ($keys as $key) {
        if (strpos($fieldName, $key) !== false) {
            return true;
        }
    }
    return false;
}

add_action('wpforms_process_complete', 'send_wpforms_data_to_external_site', 10, 4);

function send_wpforms_data_to_external_site($fields, $entry, $form_data, $entry_id) {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $config = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    $token_file = __DIR__ . '/token.php';
    if (file_exists($token_file)) {
        $token_data = include($token_file);

        // Check if the token has expired
        if (time() > $token_data['laravel_token_expiry']) {
            echo 'Token has expired.';
        } else {
            $token = $token_data['laravel_token'];
            // echo 'Token: ' . $token;
        }
    } else {
        echo 'Token file not found.';
    }

    $nameKeys = $config['wpforms']['name_keys'];
    $emailKeys = $config['wpforms']['email_keys'];
    $subjectKeys = $config['wpforms']['subject_keys'];
    $messageKeys = $config['wpforms']['message_keys'];
    $phoneKeys = $config['wpforms']['phone_keys'];

    // Loop through your $fields and check for matches
    foreach ($fields as $field) {
        if (matches($field['name'], $emailKeys)) {
            $email = $field['value'];
        } elseif (matches($field['name'], $nameKeys)) {
            $name = $field['value'];
        } elseif (matches($field['name'], $subjectKeys)) {
            $subject = $field['value'];
        } elseif (matches($field['name'], $messageKeys)) {
            $message = $field['value'];
        } elseif (matches($field['name'], $phoneKeys)) {
            $phone = $field['value'];
        }
    }

    // Prepare the data to send
    $data = array(
        'name' => sanitize_text_field($name),
        'email' => sanitize_email($email),
        'message' => sanitize_textarea_field($message),
        'subject' => sanitize_text_field($subject),
        'phone' => sanitize_text_field($phone),
    );

    // External site URL
    $url = 'https://www.dashboard.inmoconnect.com/api/store-agent-lead-details';

    // Send data to the external site using wp_remote_post
    $response = wp_remote_post($url, array(
        'method'    => 'POST',
        'body'      => $data,
        'headers'   => array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type' => 'application/x-www-form-urlencoded'
        ),
    ));

    // Optionally, log or handle the response
    if (is_wp_error($response)) {
        // Log error
        echo '<pre>';print_r($response);echo '</pre>';die();
    } else {
        // Log success or further actions
    }
}


add_action('wp_ajax_get_import_progress', 'get_import_progress');

function get_import_progress() {
    // Get progress from the transient
    $progress = get_transient('property_import_progress');
    if ($progress) {
        wp_send_json_success($progress);
    } else {
        wp_send_json_error('No progress data available');
    }
}

function delete_old_logs_from_plugin() {
    $settings_file = plugin_dir_path(__FILE__) . '/settings.php';
    if (file_exists($settings_file)) {
        $settings_data = include($settings_file);
        $config = $settings_data;
    } else {
        echo 'Settings file not found.';
    }
    // Define the path to the logs directory inside the custom plugin folder
    $log_dir = plugin_dir_path(__FILE__) . 'logs/';
    
    // Get the dynamic retention period from config.php
    // $days = defined('LOG_RETENTION_DAYS') ? LOG_RETENTION_DAYS : 7;
    $days = $config['log_deletion_days'];
    
    // Convert days to seconds
    $retention_time = time() - ($days * 24 * 60 * 60);
    
    // Check if the log directory exists
    if (is_dir($log_dir)) {
        // Get all log files in the directory with .txt extension
        $log_files = glob($log_dir . '*.txt');
        
        foreach ($log_files as $log_file) {
            // Get the last modification time of the file
            if (filemtime($log_file) < $retention_time) {
                // Delete the log file if it's older than the retention time
                unlink($log_file);
            }
        }
    }
}

// Schedule the cron job to delete old logs daily
if (!wp_next_scheduled('delete_old_plugin_logs_cron')) {
    wp_schedule_event(time(), 'daily', 'delete_old_plugin_logs_cron');
}

// Hook the function to the cron job
add_action('delete_old_plugin_logs_cron', 'delete_old_logs_from_plugin');

// function choose_property_type(){
//     global $wpdb;
    
//     // Get all unique property types from the post table
//     $property_types = $wpdb->get_col("
//         SELECT DISTINCT post_type 
//         FROM {$wpdb->posts}
//     ");

//     echo '<div class="wrap">';
//     echo '<h1>Choose Property Type</h1>';
//     echo '<form method="post" id="choose_property_type_form">';
//     echo '<select name="selected_property_type">';
//     echo '<option value="">All Property Types</option>';
    
//     foreach ($property_types as $type) {
//         echo '<option value="' . esc_attr($type) . '">' . esc_html($type) . '</option>';
//     }
    
//     echo '</select>';
//     echo '<input type="submit" name="choose_property_type" value="Continue" class="button button-primary">';
//     echo '</form>';
//     echo '</div>';
// }

// add_action('logout_from_laravel', 'logout_from_laravel_function');

function logout_from_laravel_function() {
    global $wpdb;
    //! remove from user meta
    delete_user_meta(get_current_user_id(), 'laravel_user_email');
    delete_user_meta(get_current_user_id(), 'laravel_user_pass');
    delete_user_meta(get_current_user_id(), 'laravel_token');
    delete_user_meta(get_current_user_id(), 'laravel_token_expiry');
    exit;
}

add_action('wp_ajax_logout_from_laravel', 'logout_from_laravel_function');

?>