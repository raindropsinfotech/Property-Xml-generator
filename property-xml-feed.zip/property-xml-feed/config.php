<?php
// Define constants or configuration array
// define('PLUGIN_VERSION', '1.0.0');

// Get the current user ID
$user_id = get_current_user_id();

// Retrieve the stored token from user meta
$token = get_user_meta($user_id, 'laravel_token', true);

$xml_structure = array(
    'property_information' => array(
        'property_type', 'property_title', 'property_refrence', 'bedrooms', 'bathrooms', 'status_completion', 'description'
    ),
    'property_pricing' => array(
        'listed_as', 'sale_price', 'percentage'
    ),
    'property_location' => array(
        'street_number', 'street', 'street_name', 'city', 'state', 'country', 'postcode', 'address'
    ),
    'property_dimensions' => array(
        'total_size'
    ),
    'property_media' => array(
        'property_images'
    )
);

$name_keys = ['your-name', 'name', 'firstname', 'fullname', 'user_name'];
$email_keys = ['your-email', 'email', 'email_address', 'user_email', 'contact_email'];
$phone_keys = ['your-phone', 'phone', 'phonenumber', 'number', 'mobile'];
$subject_keys = ['your-subject', 'subject', 'topic', 'your_topic', 'form_subject'];
$message_keys = ['your-message', 'message', 'comments', 'your_comment', 'form_message'];

$name_keys_wpform = ['your-name', 'name', 'firstname', 'fullname', 'user_name', 'Name'];
$email_keys_wpform = ['your-email', 'email', 'email_address', 'user_email', 'contact_email', 'Email'];
$phone_keys_wpform = ['your-phone', 'phone', 'phonenumber', 'number', 'mobile', 'Mobile'];
$subject_keys_wpform = ['your-subject', 'subject', 'topic', 'your_topic', 'form_subject' , 'Subject'];
$message_keys_wpform = ['your-message', 'message', 'comments', 'your_comment', 'form_message', 'Message'];

$config = array(
    'feed_data' => $xml_structure,
    'logo' => 'https://www.inmoconnect.com/img/landing-logo.png',
    'token' => $token,
    'cron_time' => '300',
    'log_deletion_days' => '7',
    'property_type' => array(
        'property'
    ),
    'contact_form7' => [
        'name_keys' => $name_keys,
        'email_keys' => $email_keys,
        'phone_keys' => $phone_keys,
        'subject_keys' => $subject_keys,
        'message_keys' => $message_keys
    ],
    'wpforms' => [
        'name_keys' => $name_keys_wpform,
        'email_keys' => $email_keys_wpform,
        'phone_keys' => $phone_keys_wpform,
        'subject_keys' => $subject_keys_wpform,
        'message_keys' => $message_keys_wpform
    ],
    'export_xml_feed_pagination_limit' => 10,
);
define('CONFIG', $config);
