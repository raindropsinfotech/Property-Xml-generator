<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

require_once plugin_dir_path(__FILE__) . '../config.php';
// Now you can access the config array or constants
global $config;

//! show shortcode code
do_shortcode('[laravel_login_form]');

// Get current date to use in the log filename
$current_date = date('Y-m-d');
// Define the path for the log file, using the date
$pluginData = get_plugin_data( __DIR__ );
$pluginName = $pluginData['TextDomain'];
$log_file = WP_PLUGIN_DIR . '/'.$pluginName.'/logs/inmoconnect_log_export_' . $current_date . '.txt';

// Check if file exists, if not create one
if (!file_exists($log_file)) {
    // Create a new file and add header content (optional)
    $log_data = "Log File Created on: " . date('Y-m-d H:i:s') . "\n";
    $log_data .= "=====================================\n";
    file_put_contents($log_file, $log_data, FILE_APPEND | LOCK_EX);
}

// Start logging data
$log_data = "XML Feed generation started on: " . date('Y-m-d H:i:s') . "\n";

$requirements = my_custom_plugin_check_requirements();
if(empty($requirements['all_requirements_met']) || $requirements['all_requirements_met'] == ""){
    // wp_redirect('/wp-admin?page=my_custom_plugin_setup_wizard');
    echo '<div class="notice notice-error is-dismissible"><p>Requirements not met.</p></div>';
    echo '<a href="/wp-admin?page=my_custom_plugin_setup_wizard">Go to Setup Wizard</a>';
    exit;
}

// Fetch available tables (for simplicity, assuming custom fields in 'property' post type)
function get_property_custom_fields() {
    global $wpdb;

    // Fetch distinct meta keys from wp_postmeta for 'property' post type
    $meta_keys = $wpdb->get_col("SELECT DISTINCT meta_key FROM {$wpdb->postmeta} WHERE post_id IN (SELECT ID FROM {$wpdb->posts} WHERE post_type = '".get_option('property_xml_feed_post_type', 'property')."')");

    // Add 'post_title' and 'post_content' to the list of available fields
    $default_fields = array('post_title', 'post_content');

    // Merge default fields (title, content) with custom meta keys
    $all_fields = array_merge($default_fields, $meta_keys);

    return $all_fields;
}


// Fetch saved mappings
$mappings = get_option('property_xml_feed_mappings', array());

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_mappings'])) {
    check_admin_referer('property_xml_feed_save_mappings', 'property_xml_feed_nonce');

    $mappings = isset($_POST['mappings']) ? array_map('sanitize_text_field', $_POST['mappings']) : array();
    update_option('property_xml_feed_mappings', $mappings);
    echo '<div class="notice notice-success is-dismissible"><p>Mappings saved successfully.</p></div>';
}


$xml_structure = $config['feed_data'];

function choose_property_type(){
    global $wpdb;
    
    // Get all unique property types from the post table
    $property_types = $wpdb->get_col("
        SELECT DISTINCT post_type 
        FROM {$wpdb->posts} 
        WHERE post_type != 'revision' 
        AND post_type != 'nav_menu_item'
        AND post_type != 'custom_css'
        AND post_type != 'customize_changeset'
        AND post_type != 'oembed_cache'
    ");

    echo '<div class="wrap">';
    echo '<h1>Choose Property Type</h1>';
    echo '<form method="post" id="choose_property_type_form">';
    echo '<select name="selected_property_type">';
    echo '<option value="">All Property Types</option>';
    
    foreach ($property_types as $type) {
        echo '<option value="' . esc_attr($type) . '">' . esc_html($type) . '</option>';
    }
    
    echo '</select>';
    echo '<input type="submit" name="choose_property_type" value="Continue" class="button button-primary">';
    echo '</form>';
    echo '</div>';
}

if(isset($_POST['selected_property_type'])){
    //! get the xml feed url from database
    $xml_feed_url = get_option('xml_feed_url');
    $selected_property_type = sanitize_text_field($_POST['selected_property_type']);
    //! set the selected property type in the database
    update_option('property_xml_feed_post_type', $selected_property_type);
    inject_reference_id_on_activation();
}

if(get_option('property_xml_feed_post_type') == ""){
    choose_property_type();
}else{
?>
    <div class="wrap">
        
        <h1>Export Property XML Feed</h1>
        <form method="post">
            <?php wp_nonce_field('property_xml_feed_save_mappings', 'property_xml_feed_nonce'); ?>
            <table class="form-table">
                <?php foreach ($xml_structure as $section => $fields): ?>
                    <tr>
                        <th colspan="2"><h2><?php echo ucfirst(str_replace('_', ' ', $section)); ?></h2></th>
                    </tr>
                    <?php foreach ($fields as $field): ?>
                        <tr>
                            <th scope="row"><?php echo ucfirst(str_replace('_', ' ', $field)); ?></th>
                            <td>
                                <select name="mappings[<?php echo esc_attr($section . '_' . $field); ?>]" >
                                    <option value="">-- Select Property Field --</option>
                                    <?php
                                    $custom_fields = get_property_custom_fields();
                                    foreach ($custom_fields as $cf):
                                        ?>
                                        <option value="<?php echo esc_attr($cf); ?>" <?php selected($mappings[$section . '_' . $field] ?? '', $cf); ?>>
                                            <?php echo esc_html($cf); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </table>
            <?php submit_button('Save Mappings', 'primary', 'save_mappings'); ?>
        </form>

        <hr />

        <h2>Generate XML Feed</h2>
        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
            <?php
            // Action for generating the feed
            ?>
            <input type="hidden" name="action" value="generate_property_xml_feed">
            <?php wp_nonce_field('generate_property_xml_feed_action', 'generate_property_xml_feed_nonce'); ?>
            <?php submit_button('Generate XML Feed'); ?>
        </form>
    </div>
<?php
}
?>