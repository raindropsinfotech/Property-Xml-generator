jQuery(document).ready(function($) {
    // Show the modal on page load
    var modal = $('#myCustomPluginWizardModal');
    modal.show();

    // Close the modal when the close button is clicked
    $('.my-custom-plugin-close').click(function() {
        modal.hide();
    });

    // Handle next button clicks
    $('.next-btn').click(function() {
        var nextStep = $(this).data('next');
        $('.wizard-step').hide();  // Hide all steps
        $('#wizard-step-' + nextStep).show();  // Show the next step
    });

    // Handle the finish button click
    $('.finish-btn').click(function() {
        modal.hide();
        alert('Setup complete!');
    });

    // Close modal if user clicks outside of modal content
    $(window).click(function(event) {
        if ($(event.target).is(modal)) {
            modal.hide();
        }
    });
});