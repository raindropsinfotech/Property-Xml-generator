<?php return array (
  'logo' => 'https://www.inmoconnect.com/img/landing-logo.png',
  'cron_time' => 300,
  'log_deletion_days' => 7,
  'contact_form7' => 
  array (
    'name_keys' => 
    array (
      0 => 'your-name',
      1 => 'name',
      2 => 'firstname',
      3 => 'fullname',
      4 => 'user_name',
    ),
    'email_keys' => 
    array (
      0 => 'your-email',
      1 => 'email',
      2 => 'email_address',
      3 => 'user_email',
      4 => 'contact_email',
    ),
    'phone_keys' => 
    array (
      0 => 'your-phone',
      1 => 'phone',
      2 => 'phonenumber',
      3 => 'number',
      4 => 'mobile',
    ),
    'subject_keys' => 
    array (
      0 => 'your-subject',
      1 => 'subject',
      2 => 'topic',
      3 => 'your_topic',
      4 => 'form_subject',
    ),
    'message_keys' => 
    array (
      0 => 'your-message',
      1 => 'message',
      2 => 'comments',
      3 => 'your_comment',
      4 => 'form_message',
    ),
  ),
  'wpforms' => 
  array (
    'name_keys' => 
    array (
      0 => 'your-name',
      1 => 'name',
      2 => 'firstname',
      3 => 'fullname',
      4 => 'user_name',
      5 => 'Name',
    ),
    'email_keys' => 
    array (
      0 => 'your-email',
      1 => 'email',
      2 => 'email_address',
      3 => 'user_email',
      4 => 'contact_email',
      5 => 'Email',
    ),
    'phone_keys' => 
    array (
      0 => 'your-phone',
      1 => 'phone',
      2 => 'phonenumber',
      3 => 'number',
      4 => 'mobile',
      5 => 'Mobile',
    ),
    'subject_keys' => 
    array (
      0 => 'your-subject',
      1 => 'subject',
      2 => 'topic',
      3 => 'your_topic',
      4 => 'form_subject',
      5 => 'Subject',
    ),
    'message_keys' => 
    array (
      0 => 'your-message',
      1 => 'message',
      2 => 'comments',
      3 => 'your_comment',
      4 => 'form_message',
      5 => 'Message',
    ),
  ),
  'export_xml_feed_pagination_limit' => 10,
);